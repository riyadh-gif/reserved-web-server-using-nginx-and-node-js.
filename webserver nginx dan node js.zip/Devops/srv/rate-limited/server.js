const express = require('express');
const http = require('http');

const app = express();
app.get('/', function (req, res) {
  res.send('Riyadh Hadinah Ahtar Lakadimu');
});

const server = http.createServer(app).listen(4000, function(err) {
  if (err) {
    console.log(err);
  } else {
    const host = server.address().address;
    const port = server.address().port;
    console.log(`Server listening on ${host}:${port}`);
  }
});
